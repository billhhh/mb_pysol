import pysol
import target_process
import numpy
class ogd:

	def __init__(self,**params):
		self.params=params

	
	def fit(self,X,Y):
		[Y_new,self.old_to_new,self.new_to_old,num_class]=target_process.translate(Y)
		try: 
			train_accuracy=self.classifier.fit(X,Y_new)
			return train_accuracy		    
		except AttributeError as e:
			self.classifier=pysol.SOL('ogd',num_class,**self.params)
			train_accuracy=self.classifier.fit(X,Y_new)
			return train_accuracy
	@property
	def coef_(self, cls_id=0):
		return self.classifier.get_weight(cls_id)
	
	def predict(self, X):
		Y_predict=self.classifier.predict(X)
		Y_original=numpy.empty(shape=[0,len(Y_predict)])
		for i in range(len(Y_predict)):
			Y_original=numpy.append(Y_original,self.new_to_old[Y_predict[i]])
		return Y_original
