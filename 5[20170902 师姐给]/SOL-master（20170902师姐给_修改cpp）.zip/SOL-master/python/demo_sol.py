import numpy
import scipy
from sklearn.datasets import load_svmlight_file
from sol_classifiers import ogd
import time

X_train,Y_train=load_svmlight_file("../data/a1a.t")
X_test,Y_test=load_svmlight_file("../data/a1a")

start_time = time.time()
clf=ogd(eta=0.1)
train_accuracy=clf.fit(X_train,Y_train)
print("training accuracy:")
print(train_accuracy)
train_time = time.time() - start_time

print("training time cost")
print(train_time)
print("sparsity")
print(clf.classifier.sparsity)

print("prediction of instance 0")
y=clf.predict(X_test[0])
print(y)

print("model weight")
print(clf.coef_)

clf.classifier.save("cur_model")

print("along the learning process")
clf_2=ogd(eta=0.1)
print(clf_2.fit(X_train[0:100],Y_train[0:100]))
print(clf_2.fit(X_train[100:200],Y_train[100:200]))
print(clf_2.fit(X_train[200:300],Y_train[200:300]))
print(clf_2.fit(X_train[300:400],Y_train[300:400]))





